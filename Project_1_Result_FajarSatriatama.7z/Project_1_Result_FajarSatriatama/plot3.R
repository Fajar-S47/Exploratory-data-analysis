 setwd("C:/Users/fsatria/OneDrive - PT XL Axiata Tbk/Fajar's Document/Training/Coursera/R Training/Exploratory data analysis/Project 1")
> hpcDT <- data.table::fread(input = "household_power_consumption.txt", na.strings="?")
> hpcDT[, Global_active_power := lapply(.SD, as.numeric), .SDcols = c("Global_active_power")]
> head(hpcDT)
         Date     Time Global_active_power Global_reactive_power Voltage Global_intensity Sub_metering_1 Sub_metering_2 Sub_metering_3
1: 16/12/2006 17:24:00               4.216                 0.418  234.84             18.4              0              1             17
2: 16/12/2006 17:25:00               5.360                 0.436  233.63             23.0              0              1             16
3: 16/12/2006 17:26:00               5.374                 0.498  233.29             23.0              0              2             17
4: 16/12/2006 17:27:00               5.388                 0.502  233.74             23.0              0              1             17
5: 16/12/2006 17:28:00               3.666                 0.528  235.68             15.8              0              1             17
6: 16/12/2006 17:29:00               3.520                 0.522  235.02             15.0              0              2             17
> hpcDT[, dateTime := as.POSIXct(paste(Date, Time), format = "%d/%m/%Y %H:%M:%S")]
> head(hpcDT)
         Date     Time Global_active_power Global_reactive_power Voltage Global_intensity Sub_metering_1 Sub_metering_2 Sub_metering_3            dateTime
1: 16/12/2006 17:24:00               4.216                 0.418  234.84             18.4              0              1             17 2006-12-16 17:24:00
2: 16/12/2006 17:25:00               5.360                 0.436  233.63             23.0              0              1             16 2006-12-16 17:25:00
3: 16/12/2006 17:26:00               5.374                 0.498  233.29             23.0              0              2             17 2006-12-16 17:26:00
4: 16/12/2006 17:27:00               5.388                 0.502  233.74             23.0              0              1             17 2006-12-16 17:27:00
5: 16/12/2006 17:28:00               3.666                 0.528  235.68             15.8              0              1             17 2006-12-16 17:28:00
6: 16/12/2006 17:29:00               3.520                 0.522  235.02             15.0              0              2             17 2006-12-16 17:29:00
> hpcDT[, Date := lapply(.SD, as.Date, "%d/%m/%Y"), .SDcols = c("Date")]
> head(hpcDT)
         Date     Time Global_active_power Global_reactive_power Voltage Global_intensity Sub_metering_1 Sub_metering_2 Sub_metering_3            dateTime
1: 2006-12-16 17:24:00               4.216                 0.418  234.84             18.4              0              1             17 2006-12-16 17:24:00
2: 2006-12-16 17:25:00               5.360                 0.436  233.63             23.0              0              1             16 2006-12-16 17:25:00
3: 2006-12-16 17:26:00               5.374                 0.498  233.29             23.0              0              2             17 2006-12-16 17:26:00
4: 2006-12-16 17:27:00               5.388                 0.502  233.74             23.0              0              1             17 2006-12-16 17:27:00
5: 2006-12-16 17:28:00               3.666                 0.528  235.68             15.8              0              1             17 2006-12-16 17:28:00
6: 2006-12-16 17:29:00               3.520                 0.522  235.02             15.0              0              2             17 2006-12-16 17:29:00
> hpcDT <- hpcDT[(Date >= "2007-02-01") & (Date < "2007-02-03")]
> head(hpcDT)
         Date     Time Global_active_power Global_reactive_power Voltage Global_intensity Sub_metering_1 Sub_metering_2 Sub_metering_3            dateTime
1: 2007-02-01 00:00:00               0.326                 0.128  243.15              1.4              0              0              0 2007-02-01 00:00:00
2: 2007-02-01 00:01:00               0.326                 0.130  243.32              1.4              0              0              0 2007-02-01 00:01:00
3: 2007-02-01 00:02:00               0.324                 0.132  243.51              1.4              0              0              0 2007-02-01 00:02:00
4: 2007-02-01 00:03:00               0.324                 0.134  243.90              1.4              0              0              0 2007-02-01 00:03:00
5: 2007-02-01 00:04:00               0.322                 0.130  243.16              1.4              0              0              0 2007-02-01 00:04:00
6: 2007-02-01 00:05:00               0.320                 0.126  242.29              1.4              0              0              0 2007-02-01 00:05:00
> png("plot3.png", width=480, height=480)
> plot(hpcDT[, dateTime], hpcDT[, Sub_metering_1], type="l", xlab="", ylab="Energy Sub Metering")
> lines(hpcDT[, dateTime], hpcDT[, Sub_metering_2],col="red")
> lines(hpcDT[, dateTime], hpcDT[, Sub_metering_3],col="blue")
> legend("topright", col=c("black","red","blue"), c("Sub_metering_1  ","Sub_metering_2  ", "Sub_metering_3  "),lty=c(1,1), lwd=c(1,1))
> dev.off()
null device 
          1 
